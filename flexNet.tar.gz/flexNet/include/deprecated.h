/****************************************************************************
	Copyright (c) 2003-2010 Flexera Software, Inc. All Rights Reserved.
	This software has been provided pursuant to a License Agreement
	containing restrictions on its use.  This software contains
	valuable trade secrets and proprietary information of
	Flexera Software, Inc. and is protected by law.
	It may 	not be copied or distributed in any form or medium, disclosed
	to third parties, reverse engineered or used in any manner not
	provided for in said License Agreement except with the prior
	written authorization from Flexera Software, Inc.
*****************************************************************************/

/**	@file		Deprecated function prototypes.
 *	@brief		A brief description here
 *	@version	$Revision: #1 $
 *
 *	Function prototypes for deprecated functions.
 ****************************************************************************/

#ifndef INCLUDE_DEPRECATED_H
#define INCLUDE_DEPRECATED_H

#include "lmclient.h"

lm_extern char * API_ENTRY lc_ascii_date(LM_HANDLE * job, char * pszBdate);
lm_extern CONFIG * API_ENTRY lc_lookup(LM_HANDLE * job, char * feature);
lm_extern char * API_ENTRY lc_extract_date(LM_HANDLE * job, char * pszCode);


#endif /* INCLUDE_DEPRECATED_H */
