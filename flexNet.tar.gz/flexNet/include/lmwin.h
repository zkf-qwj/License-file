/******************************************************************************
Copyright (c) 2005-2007 Macrovision Europe Ltd. and/or Macrovision Corporation. All Rights Reserved.
    This software has been provided pursuant to a License Agreement
    containing restrictions on its use.  This software contains
    valuable trade secrets and proprietary information of 
    Macrovision Corporation and is protected by law.  It may 
    not be copied or distributed in any form or medium, disclosed 
    to third parties, reverse engineered or used in any manner not 
    provided for in said License Agreement except with the prior 
    written authorization from Macrovision Corporation.
*****************************************************************************/
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by lmwin.rc
//
#define IDC_CHECKOUT                    1000
#define IDC_CHECKIN                     1001
#define IDC_FEATURE                     1002
#define IDC_STATUS                      1003
#define IDC_ORDERNUMBERS                1005
#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
